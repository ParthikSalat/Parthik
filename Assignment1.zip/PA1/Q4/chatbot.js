// chatbot.js

class ChatBot {
  constructor() {
    this.responses = {
      'what is .net': '.NET is a software development framework for building applications.',
      'what is full stack development': 'Full stack development involves working on both front-end and back-end technologies.',
      'what is python': 'Python is a high-level programming language known for its readability and versatility.',
    };
  }

  getResponse(userInput) {
    const input = userInput.toLowerCase();
    if (this.responses[input]) {
      return this.responses[input];
    } else {
      return "I'm sorry, I don't understand your question. Please ask something related to web development.";
    }
  }
}

module.exports = ChatBot;
