const express = require('express');
const path = require('path');

const app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

app.get('/api/getData', (req, res) => {
  res.send({ message: 'Hello, this is a GET request!' });
});

app.post('/api/postData', (req, res) => {
  const data = req.body;
  res.send({ message: 'POST request received!', data: data });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
