const readline = require('readline');
const ChatBot = require('./chatbot');

const bot = new ChatBot();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: 'You: '
});

console.log('Welcome to the Web Development ChatBot!');
console.log('Ask me anything about HTML, CSS, JavaScript, React, or Node.js.');
rl.prompt();

rl.on('line', (line) => {
  const userInput = line.trim();
  const botResponse = bot.getResponse(userInput);
  console.log(`Bot: ${botResponse}`);
  rl.prompt();
}).on('close', () => {
  console.log('Goodbye!');
  process.exit(0);
});
