const fs = require('fs');
const path = require('path');
const unzipper = require('unzipper');

function extractZip(zipFilePath, outputDir) {
    fs.mkdirSync(outputDir, { recursive: true });

    fs.createReadStream(zipFilePath)
        .pipe(unzipper.Extract({ path: outputDir }))
        .on('close', () => {
            console.log(`Extraction complete! Files extracted to: ${outputDir}`);
        })
        .on('error', (err) => {
            console.error(`Error extracting ZIP file: ${err.message}`);
        });
}

// Usage
const zipFilePath = path.join(__dirname, 'output.zip'); // Change this to your zip file path
const outputDir = path.join(__dirname, 'extracted'); // Change this to your desired output directory

extractZip(zipFilePath, outputDir);
